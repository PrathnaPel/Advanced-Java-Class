package com.sweg6409.StudentDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
